<?php
$connect = mysqli_connect('localhost','root','','sig_apotik')or die("gagal, database tidak ditemukan");
?>