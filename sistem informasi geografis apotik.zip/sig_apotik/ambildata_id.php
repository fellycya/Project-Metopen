<?php
include "koneksi.php";
//$Q = mysqli_query("SELECT * FROM jasaweb where id_perusahaan=".$id)or die(mysqli_error());
//$sql= "SELECT * FROM jasaweb where id_perusahaan=".$id; // Menampung perintah SQL ke variabel ‘sql’
//$Q = $mysqli->query($sql); 

$Q= mysqli_query($connect, "SELECT * FROM apotik where id_apotik=".$id); // Menampung perintah SQL ke variabel ‘sql’




if($Q){
 $posts = array();
      if(mysqli_num_rows($Q))
      {
             while($post = mysqli_fetch_assoc($Q)){
                     $posts[] = $post;
             }
      }  
      $data = json_encode(array('results'=>$posts));             
}

?>