<div class="footer footer1">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-md-offset-4">
            <img src="img/logo.png" width="72" height="72" />
            <h4 class="white">Sistem Informasi Geografis Apotik</h4>
          <ul class="list-inline">
            <li><a href="" class="link-footer">Petunjuk Penggunaan</a></li>
            <li><a href="" class="link-footer">Tentang</a></li>
          </ul>
          <h5 class="white">Copyright &copy; SIG Apotik Kecamatan Teluk Ambon</h5>
          </div>
        </div>


        
      </div>
    </div>

    <!-- Modal -->
<div class="modal fade" id="about" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel">About</h4>
      </div>
      <div class="modal-body">
        <h4>SISTEM INFORMASI GEOGRAFIS APOTIK KECAMATAN TELUK AMBON</h4>
      </div>
    </div>
  </div>
</div>


    <!-- Modal Login -->
    <div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel">Login Admin</h4>
      </div>
      <div class="modal-body">
        <center>
      <div class="btn-group">
                    <a href="" class="btn btn-primary">
                    <i class="fa fa-user"> </i> LOGIN</a>&nbsp;
                  </div>
        </center>
      </div>
    </div>
  </div>
</div>







    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/script.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/datatable-bootstrap.js"></script>


    <script>
    $(document).ready(function () {
        //ajax edit data pegawai
        $(".edit").off("click").on("click",function() {              
           var id_data = $(this).attr("data-id");
           $.ajax({                        
                url : "aksi_edit.php?id="+id_data,
                type: "GET",
                dataType: "JSON",
                success: function(data)
                {                                    
                    $("#id").val(data.id);                     
                    $("#name").val(data.name);                     
                    $("#email").val(data.email);                     
                    $("#job").val(data.job);                     
                    $("#address").val(data.address);                     
                    $(".modal-update").modal('show');                             
                }
            });    
        });
        
        //ajax hapus data pegawai
        $(".hapus").off("click").on("click",function(){
            var id_data = $(this).attr("data-id");
            $.ajax({
                url : "aksi_hapus.php?id="+id_data,
                type : "POST",
                success : function(data){
                    window.location = "index.php";
                }
            });
        });
        
    });
    </script>

















  </body>
</html>