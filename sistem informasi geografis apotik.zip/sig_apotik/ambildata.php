<?php
include "koneksi.php";

//$Q = mysqli_query("SELECT * FROM jasaweb")or die(mysqli_error());


$Q= mysqli_query($connect, "SELECT * FROM apotik"); // Menampung perintah SQL ke variabel ‘sql’



if($Q){
 $posts = array();

      if(mysqli_num_rows($Q))
      {
             while($post = mysqli_fetch_assoc($Q)){
                     $posts[] = $post;
             }
      }  




      
      $data = json_encode(array('results'=>$posts));
      echo $data;                     
}

?>