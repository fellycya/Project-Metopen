<?php 
    include "koneksi.php";
    $id = $_GET['id'];
    
    $sql = "DELETE from apotik WHERE id_apotik=".$id;    
    $query = mysqli_query($connect,$sql);
    header("location:data_admin.php");
?>