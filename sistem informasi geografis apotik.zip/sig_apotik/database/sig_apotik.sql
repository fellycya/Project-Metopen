-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Jul 2024 pada 17.04
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sig_apotik`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `apotik`
--

CREATE TABLE `apotik` (
  `id_apotik` int(8) NOT NULL,
  `nama_apotik` varchar(255) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `website` varchar(255) NOT NULL,
  `no_hp` varchar(25) NOT NULL,
  `alamat` text NOT NULL,
  `kota` varchar(50) NOT NULL,
  `provinsi` varchar(50) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `apotik`
--

INSERT INTO `apotik` (`id_apotik`, `nama_apotik`, `kategori`, `website`, `no_hp`, `alamat`, `kota`, `provinsi`, `latitude`, `longitude`) VALUES
(1, 'Apotek Rumah Tiga', 'Umum', '-', '-', '85RP+GQ7, Rumah Tiga, Kec. Tlk. Ambon, Kota Ambon, Maluku', 'Ambon', 'Maluku', '-3.6587043', '128.1847304'),
(2, 'Apotek AGITA', 'Umum', '-', '0838-1111-2222', '85P9+CFX, Jl. Ir. M. Putuhena, Wayame, Kec. Tlk. Ambon, Kota Ambon, Maluku', 'Ambon', 'Maluku', '-3.6638835', '128.1665587'),
(3, 'Apotek Dyandra Farma', 'Klinik', '-', '0856-4839-0911', '85WW+5RC, Jl. Mr Chr. Soplanit, Poka, Kec. Tlk. Ambon, Kota Ambon, Maluku', 'Ambon', 'Maluku', '-3.6545569', '128.1948216'),
(4, 'Klinik Teluk Ambon', 'Klinik', '-', '09113825046', 'Jl. Ir. M. Putuhena, Tihu, Kec. Tlk. Ambon, Kota Ambon, Maluku 97237', 'Ambon', 'Maluku', '-3.6509283', '128.1910626'),
(5, 'Apotek NADIVA', 'Klinik', 'https://praktek-drg-rachmawati-dian-puspitasari.business.site/?utm_source=gmb&utm_medium=referral', '082292160606', 'Jl. Ir. M. Putuhena RT 004/RW 002 Wayame, Ambon', 'Ambon', 'Maluku', '-3.6647922', '128.1645201');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_user`
--

CREATE TABLE `tabel_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tabel_user`
--

INSERT INTO `tabel_user` (`id_user`, `username`, `nama`, `email`, `password`) VALUES
(1, 'admin', 'Admin', 'admin@admin.com', '827ccb0eea8a706c4c34a16891f84e7b');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `apotik`
--
ALTER TABLE `apotik`
  ADD PRIMARY KEY (`id_apotik`);

--
-- Indeks untuk tabel `tabel_user`
--
ALTER TABLE `tabel_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `apotik`
--
ALTER TABLE `apotik`
  MODIFY `id_apotik` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `tabel_user`
--
ALTER TABLE `tabel_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
