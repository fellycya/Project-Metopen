<?php 
session_start();

if (!isset($_SESSION["username"])) {
	echo "Anda harus login dulu <br><a href='login.php'>Klik disini</a>";
	exit;
}

$id_user=$_SESSION["id_user"];
$username=$_SESSION["username"];
$nama=$_SESSION["nama"];
$email=$_SESSION["email"];

$title = "Daftar Apotik Kecamatan Teluk Ambon";
include_once "header_admin.php";
include_once "koneksi.php"; ?>

      <div class="row">
        <div class="col-md-12">
          <div class="panel panel-info panel-dashboard">
            <div class="panel-heading centered">
              <h2 class="panel-title"><strong> - <?php echo $title ?> - </strong></h2>
            </div>
                    <!--<a href="tambahdata.php" class="btn btn-primary">
                    Tambah Data</a>&nbsp;-->
                    <button class="btn btn-sm btn-primary" data-toggle="modal" data-target=".modal-create">Tambah Data</button>

                  
            <div class="panel-body">
              <table class="table table-bordered table-striped table-admin">
              <thead>
                <tr>

                  <th width="10%">No.</th>
                  <th width="30%">Nama apotik</th>
                  <th width="10%">Kategori</th>
                  <th width="13%">Kota</th>
                  <th width="20%">Website</th>
                  <th width="27%">Aksi</th>
                </tr>
              </thead>
              <tbody>
              <?php
                $data = file_get_contents('http://localhost/sig_apotik/ambildata.php');
                $no=1;
                if(json_decode($data,true)){
                  $obj = json_decode($data);
                  foreach($obj->results as $item){
              ?>
              <tr>
                <td><?php echo $no; ?></td>
                <td><?php echo $item->nama_apotik; ?></td>
                <td><?php echo $item->kategori; ?></td>
                <td><?php echo $item->kota; ?></td>
                <td><?php echo $item->website; ?></td>
                <td class="ctr">
                  <div class="btn-group">
                    <a target="_blank" href="detail_admin.php?id=<?php echo $item->id_apotik; ?>" rel="tooltip" data-original-title="Lihat File" data-placement="top"><button class="btn btn-primary btn-xs">Lihat</button></a> 
<!--
                    <a href="edit_admin.php?id=<?php echo $item->id_apotik; ?>" class="btn btn-warning">
                    <i class="fa fa-edit"></i></a> 
 
                    <a href="aksi_hapus.php?id=<?php echo $item->id_apotik; ?>" class="btn btn-danger">
                    <i class="fa fa-trash"></i>hapus</a> 
              -->   
                    <a href="#" onClick="confirm_modal('aksi_hapus.php?id=<?php echo  $item->id_apotik; ?>');"><button class="btn btn-danger btn-xs" title="Hapus">Hapus</button></a> 
                  <!--<button type="button" class="btn btn-sm btn-info edit" data-id="'.$item->id_apotik.'">Edit</button>
            <button type="button" class="btn btn-sm btn-danger hapus" data-id="'.$item->id_apotik.'">Hapus</button>
                  -->

                </div>
                </td>
              </tr>
              <?php $no++; }}

              else{
                echo "data tidak ada.";
                } ?>
              
              </tbody>
            </table>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<?php include_once "footer.php" ?>



//create.php
<div class="modal modal-create" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Form Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="aksi_insert.php">
          <div class="form-group">
            <label for="name">Nama Apotek</label>
            <input type="text" class="form-control" name="name" placeholder="Masukkan Nama">            
          </div>    
          <div class="form-group">
            <label for="kategori">kategori</label>
            <input type="text" class="form-control" name="kategori" placeholder="Masukkan Umum/Klinik">            
          </div>
          <div class="form-group">
            <label for="website">Website</label>
            <input type="text" class="form-control" name="website" placeholder="Masukkan Alamat Website">            
          </div>
          <div class="form-group">
            <label for="nohp">No Hp</label>
            <input type="text" class="form-control" name="nohp" placeholder="Masukkan No Hp">            
          </div>
          <div class="form-group">
            <label for="alamat">Alamat</label>
            <textarea class="form-control" name="alamat" placeholder="Masukkan Alamat"></textarea>            
          </div>
          <div class="form-group">
            <label for="kota">Kota</label>
            <input type="text" class="form-control" name="kota" placeholder="Masukkan Kota">            
          </div>
          <div class="form-group">
            <label for="provinsi">Provinsi</label>
            <input type="text" class="form-control" name="provinsi" placeholder="Masukkan provinsi">            
          </div>
          <div class="form-group">
            <label for="latitude">Latitude</label>
            <input type="text" class="form-control" name="latitude" placeholder="Masukkan latitude">            
          </div>
          <div class="form-group">
            <label for="longitude">Longitude</label>
            <input type="text" class="form-control" name="longitude" placeholder="Masukkan longitude">            
          </div>
          <div class="modal-footer">            
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>



 <!-- Modal Popup untuk delete-->
 <div class="modal fade" id="modal_delete">
  <div class="modal-dialog">
    <div class="modal-content" style="margin-top:100px;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align:center;">Anda yakin akan menghapus data ini.. ?</h4>
      </div>
                
      <div class="modal-footer" style="margin:0px; border-top:0px; text-align:center;">
        <a href="#" class="btn btn-danger btn-sm" id="delete_link">Hapus</a>
        <button type="button" class="btn btn-success btn-sm" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>

<!-- Javascript untuk popup modal Delete-->
<script type="text/javascript">
    function confirm_modal(delete_url)
    {
      $('#modal_delete').modal('show', {backdrop: 'static'});
      document.getElementById('delete_link').setAttribute('href' , delete_url);
    }
</script>   