<?php 
$title = "Sistem Informasi Geografis Apotik Kecamatan Teluk Ambon";
include_once "header.php"; ?>
      <div class="row">
        <div class="col-md-12">
          <div class="panel panel-info panel-dashboard">
            <div class="panel-heading centered">
              <h2 class="panel-title"><strong> - Welcome Message - </strong></h2>
            </div>
            <div class="panel-body">
              <div class="centered">
                <h4>Selamat Datang di Sistem Informasi Geografis Apotek yang ada di Kec. Teluk Ambon.</h4>
                <h4>Silakan memilih menu diatas untuk melanjutkan.</h4>
              </div>
            </div>
            </div>
          </div>

        
        </div>
      </div>
    </div>
    <?php include_once "footer.php"; ?>