<?php
session_start();

if (!isset($_SESSION["username"])) {
	echo "Anda harus login dulu <br><a href='login.php'>Klik disini</a>";
	exit;
}

$id_user=$_SESSION["id_user"];
$username=$_SESSION["username"];
$nama=$_SESSION["nama"];
$email=$_SESSION["email"];

$title = "Sistem Informasi Geografis Apotik Kecamatan Teluk Ambon";
include_once "header_admin.php"; 

?>
<div class="row">
        <div class="col-md-12">
          <div class="panel panel-info panel-dashboard">
            <div class="panel-heading centered">
              <h2 class="panel-title"><strong> - Welcome Message - </strong></h2>
            </div>
            <div class="panel-body">
              <div class="centered">
                <h4>Selamat Datang di Sistem Informasi Geografis Apotek yang ada di Kec. Teluk Ambon.</h4>
                <h4>Halaman ini hanya dapat diakses setelah login.</h4>
                <p>Nama : <?php echo $nama; ?></p>
                <p>Username : <?php echo $username; ?></p>
                <p>Email : <?php echo $email; ?></p>
              </div>
            </div>
            </div>
          </div>

        
        </div>
      </div>
    </div>

    <?php include_once "footer.php"; ?>
