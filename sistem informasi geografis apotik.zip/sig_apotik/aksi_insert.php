//aksi insert
<?php 
    include "koneksi.php";    
    $sql = "INSERT INTO apotik(nama_apotik,
                            kategori,
                            website,
                            no_hp,
                            alamat,
                            kota,
                            provinsi,
                            latitude,
                            longitude)
            VALUES ('$_POST[name]',
                    '$_POST[kategori]',
                    '$_POST[website]',
                    '$_POST[nohp]',
                    '$_POST[alamat]',
                    '$_POST[kota]',
                    '$_POST[provinsi]',
                    '$_POST[latitude]',
                    '$_POST[longitude]')";
    $query = mysqli_query($connect,$sql);
    header("location:data_admin.php");
?>